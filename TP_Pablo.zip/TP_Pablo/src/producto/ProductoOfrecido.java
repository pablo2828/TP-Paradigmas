package producto;

public abstract class ProductoOfrecido {
	protected String nombre;
	protected String tipo;

	public ProductoOfrecido(String nombre, String tipo) {
		super();
		this.nombre = nombre;
		this.tipo = tipo;
	}

	public void mostrarProducto() {
		System.out.println(this);
	}

	public String getNombre() {
		return nombre;
	}

	public String getTipo() {
		return tipo;
	}

	public abstract void descontarCupo();

	public abstract Double getDuracion();

	public abstract boolean tieneCupo();

	public abstract int getPrecio();

	public abstract String toString();
}