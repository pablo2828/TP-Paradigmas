package producto;

public class Atraccion extends ProductoOfrecido {
	private Integer cupo;
	private Double duracion;
	private Integer precioAtraccion;

	public Atraccion(String nombre, String tipo, Integer cupo, Double duracion, Integer precioAtraccion) {
		super(nombre, tipo);
		this.cupo = cupo;
		this.duracion = duracion;
		this.precioAtraccion = precioAtraccion;
	}

	@Override
	public int getPrecio() {
		return precioAtraccion;
	}

	@Override
	public Double getDuracion() {
		return duracion;
	}

	@Override
	public String toString() {
		return "\nAtraccion" + "\nNombre: [" + nombre + "]\n-Precio: $" + precioAtraccion + "\n-Duracion: " + duracion
				+ " horas";
	}

	@Override
	public void descontarCupo() {
		cupo--;
	}

	@Override
	public boolean tieneCupo() {
		if (this.cupo > 0)
			return true;
		return false;
	}
}
