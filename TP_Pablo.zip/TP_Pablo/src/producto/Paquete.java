package producto;

import java.util.ArrayList;

import promocion.Promocion;

public class Paquete extends ProductoOfrecido {

	private ArrayList<Atraccion> listaAtracciones;
	private Promocion promocion;
	private Integer precioOriginal;
	private Integer precioFinal;
	private Double duracionTotal;
	private String nombreDeAtracciones;

	public Paquete(String nombre, String tipo, ArrayList<Atraccion> listaAtracciones, Promocion promocion) {
		super(nombre, tipo);
		this.listaAtracciones = listaAtracciones;
		this.promocion = promocion;
		this.precioOriginal = this.calcularPrecio();
		this.precioFinal = promocion.calcularPrecioPromocion(this.precioOriginal);
		this.duracionTotal = this.calcularDuracion();
		this.nombreDeAtracciones = this.mostrarAtracciones();
	}

	@Override
	public int getPrecio() {
		return this.precioFinal;
	}

	private int calcularPrecio() {
		int suma = 0;

		for (Atraccion atraccion : listaAtracciones) {
			suma += atraccion.getPrecio();
		}

		return suma;
	}

	private double calcularDuracion() {
		double suma = 0;

		for (Atraccion atraccion : listaAtracciones) {
			suma += atraccion.getDuracion();
		}

		return suma;
	}

	private String mostrarAtracciones() {
		String salida = new String();

		for (int i = 0; i < listaAtracciones.size(); i++) {
			salida += listaAtracciones.get(i).getNombre();
			if (i < listaAtracciones.size() - 1)
				salida += ", ";
		}

		return salida;
	}

	@Override
	public Double getDuracion() {
		return this.duracionTotal;
	}

	@Override
	public String toString() {
		return "\n" + nombre + "\n" + "-Atracciones incluidas: [" + nombreDeAtracciones + "]\n-Duracion: "
				+ calcularDuracion() + " horas\n-Precio original: $" + precioOriginal + "\n-" + promocion + ": $"
				+ precioFinal + "\n";
	}

	@Override
	public void descontarCupo() {
		for (Atraccion atraccion : listaAtracciones) {
			atraccion.descontarCupo();
		}
	}

	@Override
	public boolean tieneCupo() {
		boolean noHayCupo = false;
		for (int i = 0; i < listaAtracciones.size() && !noHayCupo; i++) {

			if (!listaAtracciones.get(i).tieneCupo())
				noHayCupo = true;
		}
		return !noHayCupo;
	}

}
