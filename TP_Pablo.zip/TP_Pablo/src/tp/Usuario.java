package tp;

public class Usuario {

	private String nombre;
	private Integer presupuestoEnMiles;
	private Double tiempoDisponible;
	private String atraccionPreferida;

	public Usuario(String nombre, Integer presupuestoEnMiles, Double tiempoDisponible, String atraccionPreferida) {
		super();
		this.nombre = nombre;
		this.presupuestoEnMiles = presupuestoEnMiles;
		this.tiempoDisponible = tiempoDisponible;
		this.atraccionPreferida = atraccionPreferida;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getPresupuestoEnMiles() {
		return presupuestoEnMiles;
	}

	public Double getTiempoDisponible() {
		return tiempoDisponible;
	}

	public String getAtraccionPreferida() {
		return atraccionPreferida;
	}

	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", presupuestoEnMiles=" + presupuestoEnMiles + ", tiempoDisponible="
				+ tiempoDisponible + ", atraccionPreferida=" + atraccionPreferida + "]";
	}

	public void descontarPresupuestoEnMiles(int monto) {
		this.presupuestoEnMiles -= monto;
	}

	public void descontarTiempoDisponible(Double horas) {
		this.tiempoDisponible -= horas;
	}
}
