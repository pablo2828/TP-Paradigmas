package tp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import producto.Atraccion;
import producto.Paquete;
import producto.ProductoOfrecido;
import promocion.Promocion;
import promocion.PromocionPorcentual;

public class Main {

	public static void main(String[] args) {

		Atraccion montaña = new Atraccion("La montaña loca", "Aventura", 100, 2.5, 500);
		Atraccion trampolin = new Atraccion("El trampolin", "Aventura", 500, 2.5, 200);

		montaña.mostrarProducto();
		trampolin.mostrarProducto();

		ArrayList<Atraccion> atraccionesAventura = new ArrayList<Atraccion>();
		atraccionesAventura.add(trampolin);
		atraccionesAventura.add(montaña);
		Promocion promo1 = new PromocionPorcentual(10);
		Paquete aventura = new Paquete("Promocion", "Aventura", atraccionesAventura, promo1);
		aventura.mostrarProducto();

		ArrayList<ProductoOfrecido> atraccionesParaOfrecer = new ArrayList<ProductoOfrecido>();
		atraccionesParaOfrecer.add(aventura);

		Atraccion sillas = new Atraccion("Las Sillas", "Aventura", 5, 2.5, 1000);
		atraccionesParaOfrecer.add(sillas);

		Atraccion paseo = new Atraccion("El Paseo", "Paseo", 5, 2.5, 1000);
		atraccionesParaOfrecer.add(paseo);

		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios.add(new Usuario("Adolfo", 100000, 10.0, "Aventura"));
		usuarios.add(new Usuario("Bruno", 700000, 10.0, "Paseo"));

		// clase principal que maneja el tp
		System.out.println("\tBienvenido a Truismo en la Tierra Media");
		System.out.println("-------------------------------------------------------\n");
		for (Usuario usuario : usuarios) {
			String preferencia = usuario.getAtraccionPreferida();
			System.out.println("Nombre del visitante: " + usuario.getNombre() + "\n");
			Collections.sort(atraccionesParaOfrecer, new Comparator<ProductoOfrecido>() {
				@Override
				public int compare(ProductoOfrecido p1, ProductoOfrecido p2) {
					if (p1.getTipo().equals(preferencia) && p2.getTipo().equals(preferencia)) {
						return p2.getPrecio() - p1.getPrecio();
					}
					if (p1.getTipo().equals(preferencia) && !p2.getTipo().equals(preferencia)) {
						return -1;
					}
					if (!p1.getTipo().equals(preferencia) && p2.getTipo().equals(preferencia)) {
						return 1;
					}
					return p2.getPrecio() - p1.getPrecio();
				}
			});

			boolean[] ofrecidos = new boolean[atraccionesParaOfrecer.size()];
			boolean seguirOfreciendo = true;

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // Ya tenemos el "lector"

			while (seguirOfreciendo) {
				ProductoOfrecido productoAOfrecer = null;
				boolean encontrado = false;
				int i = 0;
				for (; i < ofrecidos.length && !encontrado; i++) {
					if (!ofrecidos[i]) {
						ProductoOfrecido aux = atraccionesParaOfrecer.get(i);
						if (aux.tieneCupo() && aux.getPrecio() <= usuario.getPresupuestoEnMiles()
								&& aux.getDuracion() <= usuario.getTiempoDisponible()) {
							productoAOfrecer = aux;
							encontrado = true;
						}
					}
				}

				if (encontrado) {
					System.out.println(productoAOfrecer);
					try {
						String respuesta = null;
						do {
							System.out.println("\nAcepta sugerencia? Ingrese S o N");
							respuesta = br.readLine();
							if (respuesta.equals("S")) {
								System.out.println("¡Aceptada!");
								System.out.println("-------------------------------------------------------\n");
								ofrecidos[i - 1] = true;
								productoAOfrecer.descontarCupo();
								usuario.descontarTiempoDisponible(productoAOfrecer.getDuracion());
								usuario.descontarPresupuestoEnMiles(productoAOfrecer.getPrecio());
							}
						} while (!(respuesta.equals("S") || respuesta.equals("N")));
					} catch (IOException e) {
						e.printStackTrace();
					}

				} else {
					seguirOfreciendo = false;
				}
			}

			// grabar lo aceptado
		}
	}
}