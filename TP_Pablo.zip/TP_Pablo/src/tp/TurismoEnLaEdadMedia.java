package tp;

import java.util.ArrayList;

import producto.ProductoOfrecido;

public class TurismoEnLaEdadMedia {
	ArrayList<ProductoOfrecido> turismoEnLaEdadMedia;
	ArrayList<Usuario> usuarios;

	public TurismoEnLaEdadMedia(ArrayList<ProductoOfrecido> turismoEnLaEdadMedia, ArrayList<Usuario> usuarios) {
		super();
		this.turismoEnLaEdadMedia = turismoEnLaEdadMedia;
		this.usuarios = usuarios;
	}

	@Override
	public String toString() {
		return "TurismoEnLaEdadMedia [turismoEnLaEdadMedia=" + turismoEnLaEdadMedia + ", usuarios=" + usuarios + "]";
	}

}
