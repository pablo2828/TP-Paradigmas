package promocion;

public abstract class Promocion {

	public abstract int calcularPrecioPromocion(int precioOriginal);

	@Override
	public abstract String toString();

}
