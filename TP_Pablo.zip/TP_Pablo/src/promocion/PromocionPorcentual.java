package promocion;

public class PromocionPorcentual extends Promocion {

	private double descuento;

	public PromocionPorcentual(double descuento) {
		super();
		this.descuento = descuento;
	}

	@Override
	public int calcularPrecioPromocion(int precioOriginal) {
		return (int) (precioOriginal * (100 - descuento) / 100);
	}

	@Override
	public String toString() {
		return "Precio con descuento";
	}

}
